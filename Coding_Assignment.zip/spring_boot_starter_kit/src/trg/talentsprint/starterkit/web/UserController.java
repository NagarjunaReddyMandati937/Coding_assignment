package trg.talentsprint.starterkit.web;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import trg.talentsprint.starterkit.model.Skill;
import trg.talentsprint.starterkit.model.User;
import trg.talentsprint.starterkit.repository.SkillRepository;
import trg.talentsprint.starterkit.service.SecurityService;
import trg.talentsprint.starterkit.service.*;
import trg.talentsprint.starterkit.validator.UserValidator;

@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@Autowired
	private SecurityService securityService;
	@Autowired
	private SkillRepository skrepo;

	@Autowired
	private UserValidator userValidator;

	@GetMapping("/registration")
	public String registration(Model model) {
		model.addAttribute("userForm", new User());

		return "registration";
	}

	@PostMapping("/registration")
	public String registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult) {
		userValidator.validate(userForm, bindingResult);

		if (bindingResult.hasErrors()) {
			return "registration";
		}

		userService.save(userForm);

		securityService.autoLogin(userForm.getUsername(), userForm.getPasswordConfirm());

		return "redirect:/welcome";
	}

	@GetMapping("/login")
	public String login(Model model, String error, String logout) {
		if (error != null)
			model.addAttribute("error", "Your username and password is invalid.");

		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");

		return "login";
	}

	@GetMapping({ "/", "/welcome" })
	public String welcome(String user, Model model) {

		model.addAttribute("skill", SkillService.findAll());
		return "welcome";
	}
	

	@GetMapping("/new-skill")
	public String showSkillCreationForm(Model model) {
		model.addAttribute("skill", new Skill());
		return "new-skill";
	}

	@PostMapping("/add")
	public String addNewSkill(@Valid @ModelAttribute Skill sk, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "new-skill";
		}
		SkillService.save(sk);
		model.addAttribute("skill", SkillService.findAll());
		return "welcome";
	}
	@GetMapping("/{id}/delete")
	public String deleteSkill(@PathVariable Long id, Model model) {
		SkillService.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid book Id:" + id));
		SkillService.deleteById(id);
		model.addAttribute("skill", SkillService.findAll());
		return "welcome";
	}
	
	@GetMapping("/{id}")
	public String showSkillById(@PathVariable Long id, Model model) {
		Skill skill = SkillService.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalid skill Id:" + id));
		model.addAttribute("skill", skill);
		return "edit-skill";
	}
	@GetMapping("/{id}/view" )
	public String view(@PathVariable Long id, Model model) {
		Skill skill = SkillService.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalid skill Id:" + id));
		model.addAttribute("skill", skill);
		return "view-details";
	}
	

	@PostMapping("/{id}/update")
	public String updateSkill(@PathVariable Long id, @Valid @ModelAttribute Skill skill, BindingResult result,
			Model model) {
		if (result.hasErrors()) {
			return "edit-skill";
		}
		SkillService.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid Skill Id:" + id));
		SkillService.save(skill);
		model.addAttribute("skill", SkillService.findAll());
		return "welcome";
	}
	@GetMapping("/search")
	public String searchByAny(@RequestParam(name = "name") String subcategory,
			@RequestParam(name = "name") String category,@RequestParam(name = "name") String skill,
			@RequestParam(name = "name") String job_title, Model model) {
		model.addAttribute("skill", skrepo.findByAny(subcategory, category, skill, job_title));
		return "welcome";

	}
	@RequestMapping("/filter")
	public String searchByCategoryOrSubcategory(@RequestParam(name="category") String category,
			@RequestParam(name="subcategory") String subcategory, Model model) {
		model.addAttribute("skill", skrepo.findByCategoryOrSubcategory(category,subcategory));
		return "welcome";

	}
//	@RequestMapping("/subcatsearch")
//	public String searchBySubCategory(@RequestParam(name="subcategory") String subcategory, Model model) {
//		model.addAttribute("skill", skrepo.findBySubCategory(subcategory));
//		return "welcome";
//
//	}
	
	
}
