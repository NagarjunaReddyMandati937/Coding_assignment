package trg.talentsprint.starterkit.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Skill {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String skill;
	private String category;
	private String subcategory;
	private String job_title;
	private Double strength;
	
	public String getJob_title() {
		return job_title;
	}
	public void setJob_title(String job_title) {
		this.job_title = job_title;
	}
	public Double getStrength() {
		return strength;
	}
	public void setStrength(Double strength) {
		this.strength = strength;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubcategory() {
		return subcategory;
	}
	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}
	
	
	@Override
	public String toString() {
		return "Skill [id=" + id + ", skill=" + skill + ", category=" + category + ", subcategory=" + subcategory
				+ ", job_title=" + job_title + ", strength=" + strength + "]";
	}
	public Skill(long id, String skill, String category, String subcategory, String job_title, Double strength) {
		super();
		this.id = id;
		this.skill = skill;
		this.category = category;
		this.subcategory = subcategory;
		this.job_title = job_title;
		this.strength = strength;
	}
	public Skill() {
		super();
	}
		
}
