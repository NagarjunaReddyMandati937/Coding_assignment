package trg.talentsprint.starterkit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import trg.talentsprint.starterkit.model.Skill;
import trg.talentsprint.starterkit.repository.SkillRepository;


@Service
public class SkillService {
	private static SkillRepository repository;

    @Autowired
    public SkillService(SkillRepository repository) {
        this.repository = repository;
    }

    public static List<Skill> findAll() {
        return (List<Skill>) repository.findAll();
    }

    public static Optional<Skill> findById(Long id) {
        return repository.findById(id);
    }

    public static Skill save(Skill sk) {
        return repository.save(sk);
    }

    public static void deleteById(Long id) {
        repository.deleteById(id);
    }
	

}
