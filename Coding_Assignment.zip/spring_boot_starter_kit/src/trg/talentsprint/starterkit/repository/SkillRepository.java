package trg.talentsprint.starterkit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import trg.talentsprint.starterkit.model.Skill;

@Repository
public interface SkillRepository extends CrudRepository<Skill, Long> {
	@Query("select e from Skill e where e.category = ?1 or e.subcategory = ?2")
	List<Skill> findByCategoryOrSubcategory(String category,String subcategory);

	@Query("select e from Skill e where e.subcategory = ?1")
	List<Skill> findBySubCategory(String subcategory);
	
	@Query("select e from Skill e where e.subcategory = ?1 or e.category = ?2 or e.skill = ?3 or e.job_title = ?4")
	List<Skill> findByAny(String subcategory,String category,String skill,String job_title);

}
