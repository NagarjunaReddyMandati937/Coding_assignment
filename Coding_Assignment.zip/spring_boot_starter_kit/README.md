# springboot-skeleton

Springboot Project Skeleton